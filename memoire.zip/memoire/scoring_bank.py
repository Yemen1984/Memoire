# -*- coding: utf-8 -*-

#modification du dossier par défaut
import os
os.chdir("C:/Users/yeyakoubi/Documents/memoire")

#lire les données d'apprentissage
import pandas
df = pandas.read_excel("dataset_scoring_bank_subset.xlsx",0)

#premières lignes
print(df.head())

#dimensions
print(df.shape)

#noms des variables
print(df.columns.values)

#liste des variables à conserver
import numpy
lstvar = numpy.append(df.columns.values[2:],df.columns.values[0])
print(lstvar)

#découpage
dfTrain = df.loc[df.ExStatus=="train",lstvar]
dfTest = df.loc[df.ExStatus!="train",lstvar]

#dimensions
print(dfTrain.shape)
print(dfTest.shape)

#dist. fréquence
print(dfTrain.objective.value_counts(normalize=True))
print(dfTest.objective.value_counts(normalize=True))

#X et y
XTrain = dfTrain.iloc[:,:-1]
yTrain = dfTrain.iloc[:,-1]

#classe LDA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

#instanciation
lda = LinearDiscriminantAnalysis()

#apprentissage
lda.fit(XTrain,yTrain)

#affichage des coefficients
print(lda.coef_)

#affichage de la constante
print(lda.intercept_)

#X et y pour l'échantillon test
XTest = dfTest.iloc[:,:-1]
yTest = dfTest.iloc[:,-1]

#prediction
probas = lda.predict_proba(XTest)
print(probas)

#liste des classes
print(lda.classes_)

#score de 'positif'
score = probas[:,1]

#transf. en 0/1 de Y_test
pos = pandas.get_dummies(yTest).as_matrix()

#colonne de positif
pos = pos[:,1]

#nombre total de positif
import numpy
npos = numpy.sum(pos)
print(npos)

#index pour tri selon le score croissant
index = numpy.argsort(score)

#inverser pour score décroissant
index = index[::-1]

#tri des individus (des valeurs 0/1)
sort_pos = pos[index]

#somme cumulée
cpos = numpy.cumsum(sort_pos)

#rappel
rappel = cpos/npos

#nb. obs ech.test
n = yTest.shape[0]

#taille de cible
taille = numpy.arange(start=1,stop=n+1,step=1)

#passer en pourcentage
taille = taille / n

#graphique
import matplotlib.pyplot as plt
plt.title('Courbe de gain')
plt.xlabel('Taille de cible')
plt.ylabel('Rappel')
plt.xlim(0,1)
plt.ylim(0,1)
plt.scatter(taille,taille,marker='.',color='blue')
plt.scatter(taille,rappel,marker='.',color='red')
plt.show()

#recherche des 300 / 1000 en se basant sur la taille
numpy.argwhere(taille <= 0.3)

#indice = 299, ce qui est logique
#quelle est le rappel correspondant
prop_pos = rappel[299]
print(prop_pos)

#on multiple par le nombre de positifs
print(prop_pos * npos)
